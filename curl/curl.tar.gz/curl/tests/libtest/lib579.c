/***************************************************************************
 *                                  _   _ ____  _
 *  Project                     ___| | | |  _ \| |
 *                             / __| | | | |_) | |
 *                            | (__| |_| |  _ <| |___
 *                             \___|\___/|_| \_\_____|
 *
 * Copyright (C) Daniel Stenberg, <daniel@haxx.se>, et al.
 *
 * This software is licensed as described in the file COPYING, which
 * you should have received as part of this distribution. The terms
 * are also available at https://curl.se/docs/copyright.html.
 *
 * You may opt to use, copy, modify, merge, publish, distribute and/or sell
 * copies of the Software, and permit persons to whom the Software is
 * furnished to do so, under the terms of the COPYING file.
 *
 * This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 * KIND, either express or implied.
 *
 * SPDX-License-Identifier: curl
 *
 ***************************************************************************/
#include "first.h"

struct t579_WriteThis {
  int counter;
};

static bool started = FALSE;
static size_t last_ul = 0;
static size_t last_ul_total = 0;

static void progress_final_report(void)
{
  FILE *moo = curlx_fopen(libtest_arg2, "ab");
  curl_mfprintf(moo ? moo : stderr, "Progress: end UL %zu/%zu\n",
                last_ul, last_ul_total);
  if(moo)
    curlx_fclose(moo);
  else
    curl_mfprintf(stderr, "Progress: end UL, cannot open %s\n", libtest_arg2);
  started = FALSE;
}

static int t579_progress_callback(void *clientp, double dltotal, double dlnow,
                                  double ultotal, double ulnow)
{
  (void)clientp;
  (void)dltotal;
  (void)dlnow;

  if(started && ulnow <= 0.0 && last_ul) {
    progress_final_report();
  }

  last_ul = (size_t)ulnow;
  last_ul_total = (size_t)ultotal;
  if(!started) {
    FILE *moo = curlx_fopen(libtest_arg2, "ab");
    curl_mfprintf(moo ? moo : stderr, "Progress: start UL %zu/%zu\n",
                  last_ul, last_ul_total);
    if(moo)
      curlx_fclose(moo);
    else
      curl_mfprintf(stderr, "Progress: start UL, cannot open %s\n",
                    libtest_arg2);
    started = TRUE;
  }

  return 0;
}

static size_t t579_read_cb(char *ptr, size_t size, size_t nmemb, void *userp)
{
  static const char * const testpost[] = {
    "one",
    "two",
    "three",
    "and a final longer crap: four",
    NULL
  };

  struct t579_WriteThis *pooh = (struct t579_WriteThis *)userp;
  const char *data;

  if(size * nmemb < 1)
    return 0;

  data = testpost[pooh->counter];

  if(data) {
    size_t len = strlen(data);
    memcpy(ptr, data, len); /* NOLINT(bugprone-not-null-terminated-result) */
    pooh->counter++; /* advance pointer */
    return len;
  }
  return 0;                         /* no more data left to deliver */
}

static CURLcode test_lib579(const char *URL)
{
  CURL *curl;
  CURLcode result = CURLE_OK;
  struct curl_slist *slist = NULL;
  struct t579_WriteThis pooh;
  pooh.counter = 0;

  if(curl_global_init(CURL_GLOBAL_ALL) != CURLE_OK) {
    curl_mfprintf(stderr, "curl_global_init() failed\n");
    return TEST_ERR_MAJOR_BAD;
  }

  curl = curl_easy_init();
  if(!curl) {
    curl_mfprintf(stderr, "curl_easy_init() failed\n");
    curl_global_cleanup();
    return TEST_ERR_MAJOR_BAD;
  }

  slist = curl_slist_append(slist, "Transfer-Encoding: chunked");
  if(!slist) {
    curl_mfprintf(stderr, "curl_slist_append() failed\n");
    curl_easy_cleanup(curl);
    curl_global_cleanup();
    return TEST_ERR_MAJOR_BAD;
  }

  /* First set the URL that is about to receive our POST. */
  test_setopt(curl, CURLOPT_URL, URL);

  /* Now specify we want to POST data */
  test_setopt(curl, CURLOPT_POST, 1L);

  /* we want to use our own read function */
  test_setopt(curl, CURLOPT_READFUNCTION, t579_read_cb);

  /* pointer to pass to our read function */
  test_setopt(curl, CURLOPT_READDATA, &pooh);

  /* get verbose debug output please */
  test_setopt(curl, CURLOPT_VERBOSE, 1L);

  /* include headers in the output */
  test_setopt(curl, CURLOPT_HEADER, 1L);

  /* enforce chunked transfer by setting the header */
  test_setopt(curl, CURLOPT_HTTPHEADER, slist);

  test_setopt(curl, CURLOPT_HTTPAUTH, CURLAUTH_DIGEST);
  test_setopt(curl, CURLOPT_USERPWD, "foo:bar");

  /* we want to use our own progress function */
  test_setopt(curl, CURLOPT_NOPROGRESS, 0L);
  test_setopt(curl, CURLOPT_PROGRESSFUNCTION, t579_progress_callback);

  /* Perform the request, result will get the return code */
  result = curl_easy_perform(curl);

  progress_final_report();

test_cleanup:

  /* clean up the headers list */
  if(slist)
    curl_slist_free_all(slist);

  /* always cleanup */
  curl_easy_cleanup(curl);
  curl_global_cleanup();

  return result;
}
