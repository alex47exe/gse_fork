/***************************************************************************
 *                                  _   _ ____  _
 *  Project                     ___| | | |  _ \| |
 *                             / __| | | | |_) | |
 *                            | (__| |_| |  _ <| |___
 *                             \___|\___/|_| \_\_____|
 *
 * Copyright (C) Daniel Stenberg, <daniel@haxx.se>, et al.
 *
 * This software is licensed as described in the file COPYING, which
 * you should have received as part of this distribution. The terms
 * are also available at https://curl.se/docs/copyright.html.
 *
 * You may opt to use, copy, modify, merge, publish, distribute and/or sell
 * copies of the Software, and permit persons to whom the Software is
 * furnished to do so, under the terms of the COPYING file.
 *
 * This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 * KIND, either express or implied.
 *
 * SPDX-License-Identifier: curl
 *
 ***************************************************************************/
#include "first.h"

#ifndef CURL_DISABLE_WEBSOCKETS

struct ws_data {
  CURL *curl;
  char *buf;
  size_t blen;
  size_t nwrites;
  int has_meta;
  int meta_flags;
};

#define LIB2302_BUFSIZE (1024 * 1024)

static void flush_data(struct ws_data *wd)
{
  size_t i;

  if(!wd->nwrites)
    return;

  for(i = 0; i < wd->blen; ++i)
    curl_mprintf("%02x ", (unsigned char)wd->buf[i]);

  curl_mprintf("\n");
  if(wd->has_meta)
    curl_mprintf("RECFLAGS: %x\n", wd->meta_flags);
  else
    curl_mfprintf(stderr, "RECFLAGS: NULL\n");
  wd->blen = 0;
  wd->nwrites = 0;
}

static size_t add_data(struct ws_data *wd, const char *buf, size_t blen,
                       const struct curl_ws_frame *meta)
{
  if((wd->nwrites == 0) ||
     (!!meta != !!wd->has_meta) ||
     (meta && meta->flags != wd->meta_flags)) {
    if(wd->nwrites > 0)
      flush_data(wd);
    wd->has_meta = (meta != NULL);
    wd->meta_flags = meta ? meta->flags : 0;
  }

  if(wd->blen + blen > LIB2302_BUFSIZE) {
    return 0;
  }
  memcpy(wd->buf + wd->blen, buf, blen);
  wd->blen += blen;
  wd->nwrites++;
  return blen;
}

static size_t t2302_write_cb(char *buffer, size_t size, size_t nitems, void *p)
{
  struct ws_data *ws_data = p;
  size_t incoming = nitems;
  const struct curl_ws_frame *meta;
  (void)size;

  meta = curl_ws_meta(ws_data->curl);
  incoming = add_data(ws_data, buffer, incoming, meta);

  if(nitems != incoming)
    curl_mfprintf(stderr, "returns error from callback\n");
  return nitems;
}
#endif

static CURLcode test_lib2302(const char *URL)
{
#ifndef CURL_DISABLE_WEBSOCKETS
  CURL *curl;
  CURLcode result = CURLE_OK;
  struct ws_data ws_data;

  global_init(CURL_GLOBAL_ALL);

  memset(&ws_data, 0, sizeof(ws_data));
  ws_data.buf = (char *)curlx_calloc(LIB2302_BUFSIZE, 1);
  if(ws_data.buf) {
    curl = curl_easy_init();
    if(curl) {
      ws_data.curl = curl;

      curl_easy_setopt(curl, CURLOPT_URL, URL);
      /* use the callback style */
      curl_easy_setopt(curl, CURLOPT_USERAGENT, "webbie-sox/3");
      curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
      curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, t2302_write_cb);
      curl_easy_setopt(curl, CURLOPT_WRITEDATA, &ws_data);
      result = curl_easy_perform(curl);
      curl_mfprintf(stderr, "curl_easy_perform() returned %d\n", result);
      /* always cleanup */
      curl_easy_cleanup(curl);
      flush_data(&ws_data);
    }
    curlx_free(ws_data.buf);
  }
  curl_global_cleanup();
  return result;
#else
  NO_SUPPORT_BUILT_IN
#endif
}
