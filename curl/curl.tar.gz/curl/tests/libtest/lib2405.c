/***************************************************************************
 *                                  _   _ ____  _
 *  Project                     ___| | | |  _ \| |
 *                             / __| | | | |_) | |
 *                            | (__| |_| |  _ <| |___
 *                             \___|\___/|_| \_\_____|
 *
 * Copyright (C) Dmitry Karpov <dkarpov1970, 2025@gmail.com>
 *
 * This software is licensed as described in the file COPYING, which
 * you should have received as part of this distribution. The terms
 * are also available at https://curl.se/docs/copyright.html.
 *
 * You may opt to use, copy, modify, merge, publish, distribute and/or sell
 * copies of the Software, and permit persons to whom the Software is
 * furnished to do so, under the terms of the COPYING file.
 *
 * This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 * KIND, either express or implied.
 *
 * SPDX-License-Identifier: curl
 *
 ***************************************************************************/

/*
 * The purpose of this test is to test behavior of curl_multi_waitfds
 * function in different scenarios:
 *  empty multi handle (expected zero descriptors),
 *  HTTP1 amd HTTP2 (no multiplexing) two transfers (expected two descriptors),
 *  HTTP2 with multiplexing (expected one descriptors)
 *  Improper inputs to the API result in CURLM_BAD_FUNCTION_ARGUMENT.
 *  Sending an empty ufds, and size = 0 will return the number of fds needed.
 *  Sending a non-empty ufds, but smaller than the fds needed will result in a
 *    CURLM_OUT_OF_MEMORY, and a number of fds that is >= to the number needed.
 *
 *  It is also expected that all transfers run by multi-handle should complete
 *  successfully.
 */

#include "first.h"

/* ---------------------------------------------------------------- */

#define test_check(expected_fds)                                             \
  if(result != CURLE_OK) {                                                   \
    curl_mfprintf(stderr, "test failed with code: %d\n", result);            \
    goto test_cleanup;                                                       \
  }                                                                          \
  else if(fd_count != (expected_fds)) {                                      \
    curl_mfprintf(stderr, "Max number of waitfds: %u not as expected: %u\n", \
                  fd_count, expected_fds);                                   \
    result = TEST_ERR_FAILURE;                                               \
    goto test_cleanup;                                                       \
  }

#define test_run_check(option, expected_fds)    \
  do {                                          \
    result = test_run(URL, option, &fd_count);  \
    test_check(expected_fds);                   \
  } while(0)

/* ---------------------------------------------------------------- */

enum {
  TEST_USE_HTTP1 = 0,
  TEST_USE_HTTP2,
  TEST_USE_HTTP2_MPLEX
};

static size_t emptyWriteFunc(char *ptr, size_t size, size_t nmemb, void *data)
{
  (void)ptr;
  (void)data;
  return size * nmemb;
}

static CURLcode set_easy(const char *URL, CURL *curl, long option)
{
  CURLcode result = CURLE_OK;

  /* First set the URL that is about to receive our POST. */
  easy_setopt(curl, CURLOPT_URL, URL);

  /* get verbose debug output please */
  easy_setopt(curl, CURLOPT_VERBOSE, 1L);

  switch(option) {
  case TEST_USE_HTTP1:
    /* go http1 */
    easy_setopt(curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
    break;

  case TEST_USE_HTTP2:
    /* go http2 */
    easy_setopt(curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_2_0);
    break;

  case TEST_USE_HTTP2_MPLEX:
    /* go http2 with multiplexing */
    easy_setopt(curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_2_0);
    easy_setopt(curl, CURLOPT_PIPEWAIT, 1L);
    break;
  }

  /* no peer verify */
  easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
  easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);

  /* include headers */
  easy_setopt(curl, CURLOPT_HEADER, 1L);

  /* empty write function */
  easy_setopt(curl, CURLOPT_WRITEFUNCTION, emptyWriteFunc);

test_cleanup:
  return result;
}

static CURLcode test_run(const char *URL, long option,
                         unsigned int *max_fd_count)
{
  CURLMcode mresult = CURLM_OK;
  CURLM *multi = NULL;
  CURLM *multi1 = NULL;

  CURL *curl1 = NULL;
  CURL *curl2 = NULL;

  unsigned int max_count = 0;

  int still_running; /* keep number of running handles */
  CURLMsg *msg; /* for picking up messages with the transfer status */
  int msgs_left; /* how many messages are left */

  CURLcode result = CURLE_OK;

  struct curl_waitfd ufds[10];
  struct curl_waitfd ufds1[10];
  int numfds;

  easy_init(curl1);
  easy_init(curl2);

  if(set_easy(URL, curl1, option) != CURLE_OK)
    goto test_cleanup;

  if(set_easy(URL, curl2, option) != CURLE_OK)
    goto test_cleanup;

  multi_init(multi);
  multi_init(multi1);

  if(option == TEST_USE_HTTP2_MPLEX)
    multi_setopt(multi, CURLMOPT_PIPELINING, CURLPIPE_MULTIPLEX);

  multi_add_handle(multi, curl1);
  multi_add_handle(multi, curl2);

  while(!mresult) {
    /* get the count of file descriptors from the transfers */
    unsigned int fd_count = 0;
    unsigned int fd_count_chk = 0;

    mresult = curl_multi_perform(multi, &still_running);
    if(!still_running || mresult != CURLM_OK)
      break;

    /* verify improper inputs are treated correctly. */
    mresult = curl_multi_waitfds(multi, NULL, 0, NULL);

    if(mresult != CURLM_BAD_FUNCTION_ARGUMENT) {
      curl_mfprintf(stderr, "curl_multi_waitfds() return code %d instead of "
                    "CURLM_BAD_FUNCTION_ARGUMENT.\n", mresult);
      result = TEST_ERR_FAILURE;
      break;
    }

    mresult = curl_multi_waitfds(multi, NULL, 1, NULL);

    if(mresult != CURLM_BAD_FUNCTION_ARGUMENT) {
      curl_mfprintf(stderr, "curl_multi_waitfds() return code %d instead of "
                    "CURLM_BAD_FUNCTION_ARGUMENT.\n", mresult);
      result = TEST_ERR_FAILURE;
      break;
    }

    mresult = curl_multi_waitfds(multi, NULL, 1, &fd_count);

    if(mresult != CURLM_BAD_FUNCTION_ARGUMENT) {
      curl_mfprintf(stderr, "curl_multi_waitfds() return code %d instead of "
                    "CURLM_BAD_FUNCTION_ARGUMENT.\n", mresult);
      result = TEST_ERR_FAILURE;
      break;
    }

    mresult = curl_multi_waitfds(multi, ufds, 10, &fd_count);

    if(mresult != CURLM_OK) {
      curl_mfprintf(stderr, "curl_multi_waitfds() failed, code %d.\n",
                    mresult);
      result = TEST_ERR_FAILURE;
      break;
    }

    if(!fd_count)
      continue; /* no descriptors yet */

    /* verify that sending nothing but the fd_count results in at least the
     * same number of fds */
    mresult = curl_multi_waitfds(multi, NULL, 0, &fd_count_chk);

    if(mresult != CURLM_OK) {
      curl_mfprintf(stderr, "curl_multi_waitfds() failed, code %d.\n",
                    mresult);
      result = TEST_ERR_FAILURE;
      break;
    }

    if(fd_count_chk < fd_count) {
      curl_mfprintf(stderr,
                    "curl_multi_waitfds() should return at least the number "
                    "of fds needed (%u vs. %u)\n", fd_count_chk, fd_count);
      result = TEST_ERR_FAILURE;
      break;
    }

    /* checking case when we do not have enough space for waitfds */
    mresult = curl_multi_waitfds(multi, ufds1, fd_count - 1, &fd_count_chk);

    if(mresult != CURLM_OUT_OF_MEMORY) {
      curl_mfprintf(stderr, "curl_multi_waitfds() return code %d instead of "
                    "CURLM_OUT_OF_MEMORY.\n", mresult);
      result = TEST_ERR_FAILURE;
      break;
    }

    if(fd_count_chk < fd_count) {
      curl_mfprintf(stderr,
                    "curl_multi_waitfds() should return the amount of fds "
                    "needed if enough is not passed in (%u vs. %u).\n",
                    fd_count_chk, fd_count);
      result = TEST_ERR_FAILURE;
      break;
    }

    /* sending ufds with zero size, is valid */
    mresult = curl_multi_waitfds(multi, ufds, 0, NULL);

    if(mresult != CURLM_OUT_OF_MEMORY) {
      curl_mfprintf(stderr, "curl_multi_waitfds() return code %d instead of "
                    "CURLM_OUT_OF_MEMORY.\n", mresult);
      result = TEST_ERR_FAILURE;
      break;
    }

    mresult = curl_multi_waitfds(multi, ufds, 0, &fd_count_chk);

    if(mresult != CURLM_OUT_OF_MEMORY) {
      curl_mfprintf(stderr, "curl_multi_waitfds() return code %d instead of "
                    "CURLM_OUT_OF_MEMORY.\n", mresult);
      result = TEST_ERR_FAILURE;
      break;
    }

    if(fd_count_chk < fd_count) {
      curl_mfprintf(stderr,
                    "curl_multi_waitfds() should return the amount of fds "
                    "needed if enough is not passed in (%u vs. %u).\n",
                    fd_count_chk, fd_count);
      result = TEST_ERR_FAILURE;
      break;
    }

    if(fd_count > max_count)
      max_count = fd_count;

    /* Do polling on descriptors in ufds in Multi 1 */
    mresult = curl_multi_poll(multi1, ufds, fd_count, 500, &numfds);

    if(mresult != CURLM_OK) {
      curl_mfprintf(stderr, "curl_multi_poll() failed, code %d.\n", mresult);
      result = TEST_ERR_FAILURE;
      break;
    }
  }

  for(;;) {
    msg = curl_multi_info_read(multi, &msgs_left);
    if(!msg)
      break;
    if(msg->msg == CURLMSG_DONE) {
      result = msg->data.result;
    }
  }

  curl_multi_remove_handle(multi, curl1);
  curl_multi_remove_handle(multi, curl2);

test_cleanup:
  curl_easy_cleanup(curl1);
  curl_easy_cleanup(curl2);

  curl_multi_cleanup(multi);
  curl_multi_cleanup(multi1);

  if(max_fd_count)
    *max_fd_count = max_count;

  return result;
}

static CURLcode empty_multi_test(void)
{
  CURLMcode mresult = CURLM_OK;
  CURLM *multi = NULL;
  CURL *curl = NULL;

  struct curl_waitfd ufds[10];

  CURLcode result = CURLE_OK;
  unsigned int fd_count = 0;

  multi_init(multi);

  /* calling curl_multi_waitfds() on an empty multi handle. */
  mresult = curl_multi_waitfds(multi, ufds, 10, &fd_count);

  if(mresult != CURLM_OK) {
    curl_mfprintf(stderr, "curl_multi_waitfds() failed, code %d.\n", mresult);
    result = TEST_ERR_FAILURE;
    goto test_cleanup;
  }
  else if(fd_count > 0) {
    curl_mfprintf(stderr, "curl_multi_waitfds() returned non-zero count of "
                  "waitfds: %d.\n", fd_count);
    result = TEST_ERR_FAILURE;
    goto test_cleanup;
  }

  /* calling curl_multi_waitfds() on multi handle with added easy handle. */
  easy_init(curl);

  if(set_easy("http://example.com", curl, TEST_USE_HTTP1) != CURLE_OK)
    goto test_cleanup;

  multi_add_handle(multi, curl);

  mresult = curl_multi_waitfds(multi, ufds, 10, &fd_count);

  if(mresult != CURLM_OK) {
    curl_mfprintf(stderr, "curl_multi_waitfds() failed, code %d.\n", mresult);
    result = TEST_ERR_FAILURE;
    goto test_cleanup;
  }
  else if(fd_count > 0) {
    curl_mfprintf(stderr, "curl_multi_waitfds() returned non-zero count of "
                  "waitfds: %d.\n", fd_count);
    result = TEST_ERR_FAILURE;
    goto test_cleanup;
  }

  curl_multi_remove_handle(multi, curl);

test_cleanup:
  curl_easy_cleanup(curl);
  curl_multi_cleanup(multi);
  return result;
}

static CURLcode test_lib2405(const char *URL)
{
  CURLcode result = CURLE_OK;
  unsigned int fd_count = 0;

  global_init(CURL_GLOBAL_ALL);

  /* Testing curl_multi_waitfds on empty and not started handles */
  result = empty_multi_test();
  if(result != CURLE_OK)
    goto test_cleanup;

  if(testnum == 2405) {
    /* HTTP1, expected 2 waitfds - one for each transfer */
    test_run_check(TEST_USE_HTTP1, 2);
  }
#ifdef USE_HTTP2
  else { /* 2407 */
    /* HTTP2, expected 2 waitfds - one for each transfer */
    test_run_check(TEST_USE_HTTP2, 2);

    /* HTTP2 with multiplexing, expected 1 waitfds - one for all transfers */
    test_run_check(TEST_USE_HTTP2_MPLEX, 1);
  }
#endif

test_cleanup:
  curl_global_cleanup();
  return result;
}
