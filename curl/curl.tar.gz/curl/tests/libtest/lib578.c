/***************************************************************************
 *                                  _   _ ____  _
 *  Project                     ___| | | |  _ \| |
 *                             / __| | | | |_) | |
 *                            | (__| |_| |  _ <| |___
 *                             \___|\___/|_| \_\_____|
 *
 * Copyright (C) Daniel Stenberg, <daniel@haxx.se>, et al.
 *
 * This software is licensed as described in the file COPYING, which
 * you should have received as part of this distribution. The terms
 * are also available at https://curl.se/docs/copyright.html.
 *
 * You may opt to use, copy, modify, merge, publish, distribute and/or sell
 * copies of the Software, and permit persons to whom the Software is
 * furnished to do so, under the terms of the COPYING file.
 *
 * This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 * KIND, either express or implied.
 *
 * SPDX-License-Identifier: curl
 *
 ***************************************************************************/
#include "first.h"

/* The size of data should be kept below MAX_INITIAL_POST_SIZE! */
static char t578_testdata[] = "this is a short string.\n";

static size_t data_size = CURL_ARRAYSIZE(t578_testdata);

static int t578_progress_callback(void *clientp, double dltotal, double dlnow,
                                  double ultotal, double ulnow)
{
  FILE *moo = curlx_fopen(libtest_arg2, "wb");

  (void)clientp;
  (void)dltotal;
  (void)dlnow;

  if(moo) {
    if((size_t)ultotal == data_size && (size_t)ulnow == data_size)
      curl_mfprintf(moo, "PASSED, UL data matched data size\n");
    else
      curl_mfprintf(moo, "Progress callback called with UL %f out of %f\n",
                    ulnow, ultotal);
    curlx_fclose(moo);
  }
  return 0;
}

static CURLcode test_lib578(const char *URL)
{
  CURL *curl;
  CURLcode result = CURLE_OK;

  if(curl_global_init(CURL_GLOBAL_ALL) != CURLE_OK) {
    curl_mfprintf(stderr, "curl_global_init() failed\n");
    return TEST_ERR_MAJOR_BAD;
  }

  curl = curl_easy_init();
  if(!curl) {
    curl_mfprintf(stderr, "curl_easy_init() failed\n");
    curl_global_cleanup();
    return TEST_ERR_MAJOR_BAD;
  }

  /* First set the URL that is about to receive our POST. */
  test_setopt(curl, CURLOPT_URL, URL);

  /* Now specify we want to POST data */
  test_setopt(curl, CURLOPT_POST, 1L);

  /* Set the expected POST size */
  test_setopt(curl, CURLOPT_POSTFIELDSIZE, (long)data_size);
  test_setopt(curl, CURLOPT_POSTFIELDS, t578_testdata);

  /* we want to use our own progress function */
  test_setopt(curl, CURLOPT_NOPROGRESS, 0L);
  test_setopt(curl, CURLOPT_PROGRESSFUNCTION, t578_progress_callback);

  /* get verbose debug output please */
  test_setopt(curl, CURLOPT_VERBOSE, 1L);

  /* include headers in the output */
  test_setopt(curl, CURLOPT_HEADER, 1L);

  /* Perform the request, result will get the return code */
  result = curl_easy_perform(curl);

test_cleanup:

  /* always cleanup */
  curl_easy_cleanup(curl);
  curl_global_cleanup();

  return result;
}
