/***************************************************************************
 *                                  _   _ ____  _
 *  Project                     ___| | | |  _ \| |
 *                             / __| | | | |_) | |
 *                            | (__| |_| |  _ <| |___
 *                             \___|\___/|_| \_\_____|
 *
 * Copyright (C) Daniel Stenberg, <daniel@haxx.se>, et al.
 *
 * This software is licensed as described in the file COPYING, which
 * you should have received as part of this distribution. The terms
 * are also available at https://curl.se/docs/copyright.html.
 *
 * You may opt to use, copy, modify, merge, publish, distribute and/or sell
 * copies of the Software, and permit persons to whom the Software is
 * furnished to do so, under the terms of the COPYING file.
 *
 * This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 * KIND, either express or implied.
 *
 * SPDX-License-Identifier: curl
 *
 ***************************************************************************/
#include "first.h"

static CURLcode test_lib1559(const char *URL)
{
  static const int EXCESSIVE = 10 * 1000 * 1000;

  CURLcode result = CURLE_OK;
  CURL *curl = NULL;
  char *longurl = NULL;
  CURLU *u;
  (void)URL;

  global_init(CURL_GLOBAL_ALL);
  easy_init(curl);

  longurl = curlx_malloc(EXCESSIVE);
  if(!longurl) {
    result = TEST_ERR_MAJOR_BAD;
    goto test_cleanup;
  }

  memset(longurl, 'a', EXCESSIVE);
  longurl[EXCESSIVE - 1] = 0;

  result = curl_easy_setopt(curl, CURLOPT_URL, longurl);
  curl_mprintf("CURLOPT_URL %d bytes URL == %d\n",
               EXCESSIVE, result);

  result = curl_easy_setopt(curl, CURLOPT_POSTFIELDS, longurl);
  curl_mprintf("CURLOPT_POSTFIELDS %d bytes data == %d\n",
               EXCESSIVE, result);

  u = curl_url();
  if(u) {
    CURLUcode uc = curl_url_set(u, CURLUPART_URL, longurl, 0);
    curl_mprintf("CURLUPART_URL %d bytes URL == %d (%s)\n",
                 EXCESSIVE, uc, curl_url_strerror(uc));
    uc = curl_url_set(u, CURLUPART_SCHEME, longurl, CURLU_NON_SUPPORT_SCHEME);
    curl_mprintf("CURLUPART_SCHEME %d bytes scheme == %d (%s)\n",
                 EXCESSIVE, uc, curl_url_strerror(uc));
    uc = curl_url_set(u, CURLUPART_USER, longurl, 0);
    curl_mprintf("CURLUPART_USER %d bytes user == %d (%s)\n",
                 EXCESSIVE, uc, curl_url_strerror(uc));
    curl_url_cleanup(u);
  }

test_cleanup:
  curlx_free(longurl);
  curl_easy_cleanup(curl);
  curl_global_cleanup();

  return result; /* return the final return code */
}
