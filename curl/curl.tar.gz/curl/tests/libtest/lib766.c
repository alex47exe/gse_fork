/***************************************************************************
 *                                  _   _ ____  _
 *  Project                     ___| | | |  _ \| |
 *                             / __| | | | |_) | |
 *                            | (__| |_| |  _ <| |___
 *                             \___|\___/|_| \_\_____|
 *
 * Copyright (C) Daniel Stenberg, <daniel@haxx.se>, et al.
 *
 * This software is licensed as described in the file COPYING, which
 * you should have received as part of this distribution. The terms
 * are also available at https://curl.se/docs/copyright.html.
 *
 * You may opt to use, copy, modify, merge, publish, distribute and/or sell
 * copies of the Software, and permit persons to whom the Software is
 * furnished to do so, under the terms of the COPYING file.
 *
 * This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 * KIND, either express or implied.
 *
 * SPDX-License-Identifier: curl
 *
 ***************************************************************************/

#include "first.h"

static int sockopt_766(void *clientp,
                       curl_socket_t curlfd,
                       curlsocktype purpose)
{
  (void)clientp;
  (void)curlfd;
  if(purpose == CURLSOCKTYPE_ACCEPT) {
    curl_mfprintf(stderr,
                  "Return error from CURLOPT_SOCKOPTFUNCTION callback\n");
    return 1; /* force error */
  }
  return 0;
}

static CURLcode test_lib766(const char *URL)
{
  CURL *curl = NULL;
  CURLcode result = CURLE_OK;

  start_test_timing();

  res_global_init(CURL_GLOBAL_ALL);

  easy_init(curl);
  easy_setopt(curl, CURLOPT_VERBOSE, 1L);
  easy_setopt(curl, CURLOPT_URL, URL);
  easy_setopt(curl, CURLOPT_FTPPORT, "-");
  easy_setopt(curl, CURLOPT_SOCKOPTFUNCTION, sockopt_766);

  result = curl_easy_perform(curl);

test_cleanup:

  curl_easy_cleanup(curl);
  curl_global_cleanup();

  return result;
}
