/***************************************************************************
 *                                  _   _ ____  _
 *  Project                     ___| | | |  _ \| |
 *                             / __| | | | |_) | |
 *                            | (__| |_| |  _ <| |___
 *                             \___|\___/|_| \_\_____|
 *
 * Copyright (C) Linus Nielsen Feltzing <linus@haxx.se>
 *
 * This software is licensed as described in the file COPYING, which
 * you should have received as part of this distribution. The terms
 * are also available at https://curl.se/docs/copyright.html.
 *
 * You may opt to use, copy, modify, merge, publish, distribute and/or sell
 * copies of the Software, and permit persons to whom the Software is
 * furnished to do so, under the terms of the COPYING file.
 *
 * This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 * KIND, either express or implied.
 *
 * SPDX-License-Identifier: curl
 *
 ***************************************************************************/
#include "first.h"

#include "testtrace.h"

static CURLcode test_lib2502(const char *URL)
{
  CURLcode result = CURLE_OK;
  CURL *curl[NUM_HANDLES] = { 0 };
  int running;
  CURLM *multi = NULL;
  size_t i;
  char target_url[256];
  char dnsentry[256];
  struct curl_slist *slist = NULL;
  const char *port = libtest_arg3;
  const char *address = libtest_arg2;

  (void)URL;

  curl_msnprintf(dnsentry, sizeof(dnsentry), "localhost:%s:%s", port, address);
  curl_mprintf("%s\n", dnsentry);
  slist = curl_slist_append(slist, dnsentry);
  if(!slist) {
    curl_mfprintf(stderr, "curl_slist_append() failed\n");
    goto test_cleanup;
  }

  start_test_timing();

  global_init(CURL_GLOBAL_ALL);

  multi_init(multi);

  multi_setopt(multi, CURLMOPT_MAXCONNECTS, 1L);

  /* get each easy handle */
  for(i = 0; i < CURL_ARRAYSIZE(curl); i++) {
    /* get an easy handle */
    easy_init(curl[i]);
    /* specify target */
    curl_msnprintf(target_url, sizeof(target_url),
                   "https://localhost:%s/path/2502%04zu", port, i + 1);
    target_url[sizeof(target_url) - 1] = '\0';
    easy_setopt(curl[i], CURLOPT_URL, target_url);
    /* go http2 */
    easy_setopt(curl[i], CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_3ONLY);
    easy_setopt(curl[i], CURLOPT_CONNECTTIMEOUT_MS, 5000L);
    easy_setopt(curl[i], CURLOPT_CAINFO, libtest_arg4);
    /* wait for first connection established to see if we can share it */
    easy_setopt(curl[i], CURLOPT_PIPEWAIT, 1L);
    /* go verbose */
    debug_config.nohex = TRUE;
    debug_config.tracetime = FALSE;
    test_setopt(curl[i], CURLOPT_DEBUGDATA, &debug_config);
    easy_setopt(curl[i], CURLOPT_DEBUGFUNCTION, libtest_debug_cb);
    easy_setopt(curl[i], CURLOPT_VERBOSE, 1L);
    /* include headers */
    easy_setopt(curl[i], CURLOPT_HEADER, 1L);

    easy_setopt(curl[i], CURLOPT_RESOLVE, slist);
  }

  curl_mfprintf(stderr, "Start at URL 0\n");

  for(i = 0; i < CURL_ARRAYSIZE(curl); i++) {
    /* add handle to multi */
    multi_add_handle(multi, curl[i]);

    for(;;) {
      struct timeval interval;
      fd_set rd, wr, exc;
      int maxfd = -99;

      interval.tv_sec = 1;
      interval.tv_usec = 0;

      multi_perform(multi, &running);

      abort_on_test_timeout();

      if(!running)
        break; /* done */

      FD_ZERO(&rd);
      FD_ZERO(&wr);
      FD_ZERO(&exc);

      multi_fdset(multi, &rd, &wr, &exc, &maxfd);

      /* At this point, maxfd is guaranteed to be greater or equal than -1. */

      select_test(maxfd + 1, &rd, &wr, &exc, &interval);

      abort_on_test_timeout();
    }
    curlx_wait_ms(1); /* to ensure different end times */
  }

test_cleanup:

  /* proper cleanup sequence - type PB */

  for(i = 0; i < CURL_ARRAYSIZE(curl); i++) {
    curl_multi_remove_handle(multi, curl[i]);
    curl_easy_cleanup(curl[i]);
  }

  curl_slist_free_all(slist);

  curl_multi_cleanup(multi);
  curl_global_cleanup();

  return result;
}
