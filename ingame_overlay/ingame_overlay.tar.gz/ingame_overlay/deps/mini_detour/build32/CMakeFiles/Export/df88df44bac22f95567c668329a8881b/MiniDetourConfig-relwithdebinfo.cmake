#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Nemirtingas::MiniDetour" for configuration "RelWithDebInfo"
set_property(TARGET Nemirtingas::MiniDetour APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Nemirtingas::MiniDetour PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELWITHDEBINFO "C;CXX"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/mini_detour.lib"
  )

list(APPEND _cmake_import_check_targets Nemirtingas::MiniDetour )
list(APPEND _cmake_import_check_files_for_Nemirtingas::MiniDetour "${_IMPORT_PREFIX}/lib/mini_detour.lib" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
