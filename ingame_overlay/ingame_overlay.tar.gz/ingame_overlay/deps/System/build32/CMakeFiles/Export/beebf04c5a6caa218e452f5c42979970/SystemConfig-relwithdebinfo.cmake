#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Nemirtingas::System" for configuration "RelWithDebInfo"
set_property(TARGET Nemirtingas::System APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Nemirtingas::System PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELWITHDEBINFO "CXX"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/system.lib"
  )

list(APPEND _cmake_import_check_targets Nemirtingas::System )
list(APPEND _cmake_import_check_files_for_Nemirtingas::System "${_IMPORT_PREFIX}/lib/system.lib" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
