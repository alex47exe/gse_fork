# Install script for directory: C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/install32")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Release")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "FALSE")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  if(CMAKE_INSTALL_CONFIG_NAME MATCHES "^([Dd][Ee][Bb][Uu][Gg])$")
    file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE STATIC_LIBRARY FILES "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/build32/Debug/system.lib")
  elseif(CMAKE_INSTALL_CONFIG_NAME MATCHES "^([Rr][Ee][Ll][Ee][Aa][Ss][Ee])$")
    file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE STATIC_LIBRARY FILES "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/build32/Release/system.lib")
  elseif(CMAKE_INSTALL_CONFIG_NAME MATCHES "^([Mm][Ii][Nn][Ss][Ii][Zz][Ee][Rr][Ee][Ll])$")
    file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE STATIC_LIBRARY FILES "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/build32/MinSizeRel/system.lib")
  elseif(CMAKE_INSTALL_CONFIG_NAME MATCHES "^([Rr][Ee][Ll][Ww][Ii][Tt][Hh][Dd][Ee][Bb][Ii][Nn][Ff][Oo])$")
    file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE STATIC_LIBRARY FILES "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/build32/RelWithDebInfo/system.lib")
  endif()
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/System" TYPE FILE FILES
    "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/include/System/System.h"
    "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/include/System/SystemMacro.h"
    "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/include/System/Filesystem.h"
    "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/include/System/Date.h"
    "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/include/System/Library.h"
    "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/include/System/SystemCompiler.h"
    "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/include/System/SystemCPUExtensions.h"
    "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/include/System/SystemDetector.h"
    "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/include/System/SystemExports.h"
    "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/include/System/SystemInline.h"
    "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/include/System/String.hpp"
    "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/include/System/ThreadPool.hpp"
    "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/include/System/FunctionName.hpp"
    "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/include/System/Encoding.hpp"
    "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/include/System/ClassEnumUtils.hpp"
    "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/include/System/ConstExpressions.hpp"
    "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/include/System/Endianness.hpp"
    "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/include/System/ScopedLock.hpp"
    "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/include/System/StringSwitch.hpp"
    "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/include/System/LoopBreak.hpp"
    "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/include/System/Guid.hpp"
    "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/include/System/FunctionTraits.hpp"
    "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/include/System/DotNet.hpp"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/cmake/System/SystemConfig.cmake")
    file(DIFFERENT _cmake_export_file_changed FILES
         "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/cmake/System/SystemConfig.cmake"
         "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/build32/CMakeFiles/Export/beebf04c5a6caa218e452f5c42979970/SystemConfig.cmake")
    if(_cmake_export_file_changed)
      file(GLOB _cmake_old_config_files "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/cmake/System/SystemConfig-*.cmake")
      if(_cmake_old_config_files)
        string(REPLACE ";" ", " _cmake_old_config_files_text "${_cmake_old_config_files}")
        message(STATUS "Old export file \"$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/cmake/System/SystemConfig.cmake\" will be replaced.  Removing files [${_cmake_old_config_files_text}].")
        unset(_cmake_old_config_files_text)
        file(REMOVE ${_cmake_old_config_files})
      endif()
      unset(_cmake_old_config_files)
    endif()
    unset(_cmake_export_file_changed)
  endif()
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib/cmake/System" TYPE FILE FILES "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/build32/CMakeFiles/Export/beebf04c5a6caa218e452f5c42979970/SystemConfig.cmake")
  if(CMAKE_INSTALL_CONFIG_NAME MATCHES "^([Dd][Ee][Bb][Uu][Gg])$")
    file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib/cmake/System" TYPE FILE FILES "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/build32/CMakeFiles/Export/beebf04c5a6caa218e452f5c42979970/SystemConfig-debug.cmake")
  endif()
  if(CMAKE_INSTALL_CONFIG_NAME MATCHES "^([Mm][Ii][Nn][Ss][Ii][Zz][Ee][Rr][Ee][Ll])$")
    file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib/cmake/System" TYPE FILE FILES "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/build32/CMakeFiles/Export/beebf04c5a6caa218e452f5c42979970/SystemConfig-minsizerel.cmake")
  endif()
  if(CMAKE_INSTALL_CONFIG_NAME MATCHES "^([Rr][Ee][Ll][Ww][Ii][Tt][Hh][Dd][Ee][Bb][Ii][Nn][Ff][Oo])$")
    file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib/cmake/System" TYPE FILE FILES "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/build32/CMakeFiles/Export/beebf04c5a6caa218e452f5c42979970/SystemConfig-relwithdebinfo.cmake")
  endif()
  if(CMAKE_INSTALL_CONFIG_NAME MATCHES "^([Rr][Ee][Ll][Ee][Aa][Ss][Ee])$")
    file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib/cmake/System" TYPE FILE FILES "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/build32/CMakeFiles/Export/beebf04c5a6caa218e452f5c42979970/SystemConfig-release.cmake")
  endif()
endif()

if(CMAKE_INSTALL_COMPONENT)
  if(CMAKE_INSTALL_COMPONENT MATCHES "^[a-zA-Z0-9_.+-]+$")
    set(CMAKE_INSTALL_MANIFEST "install_manifest_${CMAKE_INSTALL_COMPONENT}.txt")
  else()
    string(MD5 CMAKE_INST_COMP_HASH "${CMAKE_INSTALL_COMPONENT}")
    set(CMAKE_INSTALL_MANIFEST "install_manifest_${CMAKE_INST_COMP_HASH}.txt")
    unset(CMAKE_INST_COMP_HASH)
  endif()
else()
  set(CMAKE_INSTALL_MANIFEST "install_manifest.txt")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  string(REPLACE ";" "\n" CMAKE_INSTALL_MANIFEST_CONTENT
       "${CMAKE_INSTALL_MANIFEST_FILES}")
  file(WRITE "C:/Users/alex47exe/Documents/GitHub/gse_fork/build/deps/win/vs2022/ingame_overlay/deps/System/build32/${CMAKE_INSTALL_MANIFEST}"
     "${CMAKE_INSTALL_MANIFEST_CONTENT}")
endif()
